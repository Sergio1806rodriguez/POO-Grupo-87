import java.util.*;
public class Punto3d extends Punto{
  private double z;
  public Punto3d(){
    super();
    this.z=0;
  }
  public Punto3d(double x,double y, double z){
    super(x,y);
    this.z=z;
  }
  public double getZ(){
    return z;
  }
  public void setZ(double z){
    this.z=z;
  }

  public void moverZ(double z){
    this.z+=z;
  }
  public void moverDiag(double i){
    super.moverDiag(i);
    this.moverZ(i);
  }
  public void moverDiag(double i,double j,double k){
    super.moverDiag(i,j);
    this.moverZ(k);
  }
  public void imprimir(){
    System.out.println("("+this.getX()+" , "+this.getY()+","+z+")");
  }
  public void leer(){
    Scanner sc=new Scanner(System.in);
    super.leer();
    System.out.println("Digite la coordenada z del punto");
    z=sc.nextFloat();
    sc.close();
  }
  public double distancia(Punto3d a){
    return Math.pow(Math.pow(this.getX()-a.getX(),2)+Math.pow(this.getY()-a.getY(),2)+Math.pow(z-a.getZ(),2),0.5);
  }
  public double distancia(){
    return Math.pow(Math.pow(this.getX(),2)+Math.pow(this.getY(),2)+Math.pow(z,2),0.5);
  }
}