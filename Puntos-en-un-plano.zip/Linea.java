public class Linea{
  Punto a;
  Punto b;
  public Linea(Punto a,Punto b){
    this.a=a;
    this.b=b;
  }
  public Punto getA(){
    return a;
  }
  public Punto getB(){
    return b;
  }
  public void setA(Punto a){
    this.a=a;
  }
  public void setB(Punto b){
    this.b=b;
  }
  public double longitud(){
    return Punto.distancia(a,b);
  }
  public static double longitud(Linea l){
    return l.longitud();
  }
  public double pendiente(){
    return (b.getY()-a.getY())/(b.getX()-a.getX());
  }
  public void mover(float x,float y){
    a.moverDiag(x,y);
    b.moverDiag(x,y);
  }
}