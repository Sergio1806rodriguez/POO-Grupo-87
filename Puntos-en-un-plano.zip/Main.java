import java.util.*;
class Main {
  
  public static void main(String[] args) {
    Linea a=new Linea(new Punto(2,6),new Punto(6,9));
    System.out.println(a.pendiente());
    System.out.println(a.longitud());
    a.mover(10,10);
    }

  }